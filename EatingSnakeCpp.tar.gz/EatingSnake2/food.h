#ifndef FOOD_H
#define FOOD_H


#include <stdlib.h>
#include <time.h>
#include "locals.h"
#include "snake.h"

class Food {
public:

	int x;
	int y;

	Food();
	~Food();

	void create(
	     struct Node_st *);	//food: 创建新的食物
	point get_pos();	//food: 获得坐标

	char style = '@';
};

#endif
