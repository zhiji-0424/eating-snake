#ifndef SCORE_H
#define SCORE_H


#include <stdio.h>
#include "locals.h"


class Score {
public:

	int score;
	int highest;
	
	Score();
	~Score();

	void rmall();
	void add(int);
	void update();
	void read();
	void write();
};


#endif
