#ifndef LOCALS_H
#define LOCALS_H


#define stage_w 20
#define stage_h 20


//方向
#define to_up    '2'
#define to_down  '8'
#define to_left  '4'
#define to_right '6'

//转角标识
#define right_up    3
#define left_up     1
#define right_down  9
#define left_down   7

#define CLEAR "\33[H\33[2J" 	//\33[3J"
#define score_file "./.ll.eatingsnake2.score"

#ifndef point
typedef struct { int x, y; } point;
#endif

#ifndef null
#ifndef __cplusplus	//如果不使用C++
#define null ((void *)0)
#else	//使用C++
#define null __null
#endif //end if __cplusplus
#endif


char getin();


#endif
