#ifndef SNAKE_H
#define SNAKE_H


#include <stdlib.h>
#include <string>
#include "locals.h"


struct Node_st {
	int x;		//X坐标
	int y;		//Y坐标
	struct Node_st *next;
};

class Snake {
	struct Node_st *head;
	int len;
	int direc;

public:

	Snake();
	~Snake();

	struct Node_st *get_head();	//获得头指针
	int get_len();			//获得长度
	int get_direc();		//获得方向

	void forward();			//前进一格, 不删尾部
	void del_tail();		//删除尾部
	void change_direc(int);		//改变方向(带自动判断)
	
	char style = 'o';
};


bool is_snake_ate_food(struct Node_st *,
			point);
bool is_snake_ate_self(struct Node_st *);


#endif
