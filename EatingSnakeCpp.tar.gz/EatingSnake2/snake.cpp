#include "snake.h"


Snake::Snake()
{
	Snake::head = (struct Node_st *)
			malloc(sizeof(struct Node_st));
	Snake::head->x = stage_w/2;
	Snake::head->y = stage_h/2;
	Snake::direc = to_up;
	Snake::head->next = null;
	Snake::len = 1;
}

Snake::~Snake()
{
	struct Node_st *t1 = Snake::head;
	struct Node_st *t2 = t1;

	//从头部下一个身体节点开始删
	//最后只剩下头
	while (t1->next != null)
	{
		t2 = t1->next;
		t1->next = t1->next->next;
		free(t2);
		t2 = null;
	}
	free(Snake::head);
	Snake::head = null;
	Snake::len = 0;
}


struct Node_st *Snake::get_head()
{
	return Snake::head;
}

int Snake::get_len()
{
	return Snake::len;
}

int Snake::get_direc()
{
	return Snake::direc;
}


//更新蛇头位置
static void update_head(struct Node_st *head,
			int snake_direc)
{	
	switch (snake_direc)
	{
	case to_up:
		head->y -= 1;
		break;
	case to_down:
		head->y += 1;
		break;
	case to_left:
		head->x -= 1;
		break;
	case to_right:
		head->x += 1;
		break;
	}
	
	//碰墙后从另一侧出现
	if (head->x < 0)
	{
		head->x = stage_w-1;
	}
	else if (head->x > stage_w-1)
	{
		head->x = 0;
	}
	else if (head->y < 0)
	{
		head->y = stage_h-1;
	}
	else if (head->y > stage_h-1)
	{
		head->y = 0;
	}
}

void Snake::forward()
{
	//在头后增加一节, 坐标域复制原来头的, 
	//更新蛇头位置
	struct Node_st *t1 = (struct Node_st *)
			malloc(sizeof(struct Node_st));
	t1->next = Snake::head->next;
	Snake::head->next = t1;
	Snake::len += 1;
	
	t1->x = Snake::head->x;
	t1->y = Snake::head->y;
	
	//更新蛇头
	update_head(Snake::head, Snake::direc);
}

void Snake::del_tail()
{
	if (Snake::len > 1)
	{
		struct Node_st *t1 = Snake::head;
		struct Node_st *t2 = t1;
		if (t1 == null) { return; }
		while (t1->next != null)
		{
			t2 = t1;
			t1 = t1->next;
		}
		//删一格尾
		t2->next = null;
		free(t1);
		Snake::len -= 1;
	}
}

void Snake::change_direc(int direc)
{
	if ((((Snake::direc == to_up)
	   || (Snake::direc == to_down))
	  && ((direc == to_left)
	   || (direc == to_right)))
	 || (((Snake::direc == to_left)
	   || (Snake::direc == to_right))
	  && ((direc == to_up)
	   || (direc == to_down))))
	{
		Snake::direc = direc;
	}
}


bool is_snake_ate_food(struct Node_st *head,
			point food)
{
	if ((head->x == food.x)
	 && (head->y == food.y))
	{
		return true;
	}
	return false;
}

bool is_snake_ate_self(struct Node_st *head)
{
	if (head == null) { return false; }
	struct Node_st *t1 = head->next;
	while (t1 != null)
	{
		if ((t1->x == head->x)
			&& (t1->y == head->y))
		{
			return true;
		}
		t1 = t1->next;
	}
	return false;
}
