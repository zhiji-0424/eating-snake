#ifndef MAIN_H
#define MAIN_H


#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <pthread.h>

#include "locals.h"
#include "food.h"
#include "snake.h"
#include "score.h"


#endif
