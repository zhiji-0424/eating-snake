#include "food.h"


Food::Food()
{
	Food::x = 0;
	Food::y = 0;
	srand(time(null));
}

Food::~Food()
{
	Food::x = 0;
	Food::y = 0;
}


static bool is_in_snake(int food_x, int food_y,
			struct Node_st *head)
{
	struct Node_st *t1 = head;
	while (t1 != null)
	{
		if ((food_x == t1->x)
		 && (food_y == t1->y))
		{
			return true;
		}
		t1 = t1->next;
	}
	return false;
}

void Food::create(struct Node_st *head)
{
	do
	{
		Food::x = rand() % stage_w;
		Food::y = rand() % stage_h;
	}
	while (is_in_snake(
			Food::x, Food::y,
			head));
}

point Food::get_pos()
{
	return { x, y };
}


