#include "score.h"


Score::Score()
{
	Score::score = 0;
	Score::read();
}

Score::~Score()
{
	Score::score   = 0;
	Score::highest = 0;
}

void Score::rmall()
{
	Score::score   = 0;
	Score::highest = 0;
	Score::write();
}

void Score::add(int n)
{
	Score::score += n;
}

void Score::update()
{
	if (Score::score
	  > Score::highest)
	{
		Score::highest =
		Score::score;
	}
}

void Score::read()
{
	FILE* fp = fopen(
		score_file,
		"r");
	if (fp != NULL)
	{
		fscanf(fp,
			"%d",
			&(Score::highest));
		fclose(fp);
		return;
	}
	Score::highest = 0;
}

void Score::write()
{
	FILE* fp = fopen(
		score_file,
		"w");
	if (fp != NULL)
	{
		fprintf(fp,
			"%d",
			Score::highest);
		fclose(fp);
		Score::score = 0;
		return;
	}
}


