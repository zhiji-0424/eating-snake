/* Copyright (c) [2021] [tyri_ji]
 * [eating-snake] is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2. 
 * You may obtain a copy of Mulan PSL v2 at:
 *        http://license.coscl.org.cn/MulanPSL2 
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.  
 * See the Mulan PSL v2 for more details. * See the Mulan PSL v2 for more details.
 */

#include "./nativeView/base.h"
#include "snake/tyri_snake.h"

//如果要使用LOGI, 和LOGE请定义LOG_TAG这个宏
#define  LOG_TAG    "main"

int black = 0;
int white = 0;
int red   = 0;
int yellow1 = 0;
int yellow2 = 0;
int yellow3 = 0;
int grey  = 0;

Paint paint_black;
Paint paint_white;
Paint paint_red;
Paint paint_yellow1;
Paint paint_yellow2;
Paint paint_yellow3;
Paint paint_grey;

// Position of hand.
float x = 0.0;
float y = 0.0;

int dspw = 0;
int dsph = 0;

int text_size = 40;
int block_size = 0;
int speed = 200;
int pos_stage_y = 0;

// Position of Control key center.
int key_cx = 0;
int key_cy = 0;
float key_size = 0.0;
#define key_up    to_up
#define key_down  to_down
#define key_left  to_left
#define key_right to_right
int on_key = 0;


void onCreate()
{
	black = RGB(0,   0,   0);
	white = RGB(255, 255, 255);
	red   = RGB(255,   0,   0);
	yellow1 = RGB(255, 255, 0);
	yellow2 = RGB(255, 230, 0);
	yellow3 = RGB(255, 220, 0);
	grey  = RGB(200, 200, 200);
	
	paint_black = newPaint();
	Paint_setColor(paint_black, black);
	Paint_setTextSize(paint_black, text_size);
	
	paint_white = newPaint();
	Paint_setColor(paint_white, white);
	Paint_setTextSize(paint_white, text_size);
	
	paint_red = newPaint();
	Paint_setColor(paint_red, red);
	
	paint_yellow1 = newPaint();
	Paint_setColor(paint_yellow1, yellow1);
	paint_yellow2 = newPaint();
	Paint_setColor(paint_yellow2, yellow2);
	paint_yellow3 = newPaint();
	Paint_setColor(paint_yellow3, yellow3);
	
	paint_grey = newPaint();
	Paint_setColor(paint_grey, grey);
	
	// Snake Init. !!MUST BE DONE!!
	snake_create();
	srand(currentTimeMillis());
	food_reappear(get_snake_head());
	set_score(0);
	score_read();
	on_key = 0;
}

void onTouchEvent(int event_action, float event_x, float event_y, int index, int count, float pointersX[], float pointersY[], int pointersId[])
{
	x = event_x;
	y = event_y;
	
	if (event_action == ACTION_DOWN)
	{
		int key_x = key_cx-key_size;
		int key_y = key_cy-key_size;
		/* Up and Down. */
		if ((x > key_cx-key_size/2)
		 && (x < key_cx+key_size/2))
		{
			/* Up */
			if ((y > key_y-key_size/2)
			 && (y < key_y+key_size/2))
			{
				on_key = key_up;
			}
			else
			{
				/* Down */
				key_y = key_cy+key_size;
				if ((y > key_y-key_size/2)
				 && (y < key_y+key_size/2))
				{
					on_key = key_down;
				}
			}
		}
		/* Left and Right. */
		else if ((y > key_cy-key_size/2)
		      && (y < key_cy+key_size/2))
		{
			/* Left */
			if ((x > key_x-key_size/2)
			 && (x < key_x+key_size/2))
			{
				on_key = key_left;
			}
			else
			{
				/* Right */
				key_x = key_cx+key_size;
				if ((x > key_x-key_size/2)
				 && (x < key_x+key_size/2))
				{
					on_key = key_right;
				}
			}
		}
	}
	
	if (((event_y > 0)
	 && (event_y < (dspw-stage_h*block_size)/2+\
stage_h*block_size-pos_stage_y*1.2))
	&& ((event_action == ACTION_MOVE)
	 || (event_action == ACTION_DOWN)))
	{
		speed = 40;
		// showToastText("加速！", 0);
	}
	else
	{
		speed = 200;
	}
	
	if (event_action == ACTION_DOWN)
	if (((x > key_cx-key_size/2)
	  && (x < key_cx+key_size/2))
	 && ((y > key_cy-key_size/2)
	  && (y < key_cy+key_size/2)))
	{
		showToastText("\
提示：\n\
  按上下左右来控制方向；\n\
  按住屏幕上部分来加速；\n\
  双击返回键可退出游戏；\n\
  只有撞到自己才会更新最高分；\n\
  可以穿墙。\n\
\n反馈Bug：\n\
  zhiji_0424@qq.com\n\
\n祝：\n\
  玩得快乐！:)\
", 1);
	}
}

void onDraw(int left, int top, int right, int bottom, Canvas canvas)
{
	Canvas_drawColor(canvas, white);
	
#define DRAWRECT(x, y, w, h) drawRect((x)-(w)/2, (y)-(h)/2, (x)+(w)/2, (y)+(h)/2)
	DRAWRECT(key_cx, key_cy-key_size, key_size+2, key_size+2);
	DRAWRECT(key_cx, key_cy+key_size, key_size+2, key_size+2);
	DRAWRECT(key_cx-key_size, key_cy, key_size+2, key_size+2);
	DRAWRECT(key_cx+key_size, key_cy, key_size+2, key_size+2);
	setColor(grey);
	DRAWRECT(key_cx, key_cy-key_size, key_size, key_size);
	DRAWRECT(key_cx, key_cy+key_size, key_size, key_size);
	DRAWRECT(key_cx-key_size, key_cy, key_size, key_size);
	DRAWRECT(key_cx+key_size, key_cy, key_size, key_size);
	setColor(black);
#undef DRAWRECT
	
	Canvas_save(canvas);
	Canvas_translate(canvas, \
(dspw-stage_w*block_size)/2, \
(dspw-stage_w*block_size)/2-pos_stage_y*1.2);
	Canvas_drawRect(canvas, 0-1, 0-1, \
stage_w*block_size+1, stage_h*block_size+1, paint_black);
	Canvas_drawRect(canvas, 0, 0, \
stage_w*block_size, stage_h*block_size, paint_grey);
	draw_food(canvas, paint_red, block_size);
	draw_snake(canvas, paint_yellow1, paint_yellow2, paint_yellow3, block_size);
	char text1[32];
	sprintf(text1, "分数: %d", get_score());
	drawText(text1, 0, stage_h*block_size+text_size);
	char text2[32];
	sprintf(text2, "最高: %d", get_highest());
	if (get_score() < get_highest())
	{
		drawText(text2, 0, stage_h*block_size+text_size*2);
	}
	Canvas_restore(canvas);
	
//	char text[32];
//	sprintf(text, " x: %.0f, y: %.0f", x, y);
//	drawText(text, 0, 760);
	drawText("提示", key_cx-text_size, key_cy+text_size/2);
	
	// invalidate();
}


void onSizeChange(int w, int h, int oldw, int oldh, float density)
{
	dspw = w;
	dsph = h;
	x = w/2;
	y = h/2;
	
	block_size = (dspw/3*2)/stage_w;
	key_size = dspw/5;
	text_size = block_size*1.5;
	setTextSize(text_size);
	key_cx = dspw/2;
	key_cy = dsph-(key_size*3)/2-1;
	
	if (key_cy-(key_size*3)/2 < \
(dspw-stage_h*block_size)/2+stage_h*block_size)
	{
		pos_stage_y = \
((dspw-stage_h*block_size)/2+stage_h*block_size) \
		- (key_cy-(key_size*3)/2);
	}
}

long long time1 = 0;
long long time2 = 0;
void onLoopCall()
{
	time2 = currentTimeMillis();
	if (time2-time1 >= speed)
	{
		time1 = time2;
		
		snake_change_direc(on_key);
		snake_forward();
		if (is_snake_ate_food(get_snake_head(), get_foodxy()))
		{
			score_add(1);
			score_update();
			food_reappear(get_snake_head());
		}
		else
		{
			snake_del_tail();
		}
		if (is_snake_ate_self(get_snake_head()))
		{
			score_write();
			snake_destroy();
			on_key = 0;
			snake_create();
			set_score(0);
			showToastText("重生！", 0);
		}
		postInvalidate();
	}
}

// Last BackPress
long long lbp = 0;
int onBackPressed()
{
	if (currentTimeMillis()-lbp < 400)
	{
		return 0;
	}
	else
	{
		lbp = currentTimeMillis();
	}
	return 1;
}

//应用被暂停时调用，例如被后台运行
void onPause()
{
	// showToastText("onPause", 0);
}

//应用被恢复时调用，例如从后台运行转为前台运行
void onResume()
{
	// showToastText("onResume", 0);
}

//程序在被销毁时调用
void onDestroy()
{
	deletePaint(paint_black);
	deletePaint(paint_white);
	deletePaint(paint_red);
	deletePaint(paint_yellow1);
	deletePaint(paint_yellow2);
	deletePaint(paint_yellow3);
	deletePaint(paint_grey);
}