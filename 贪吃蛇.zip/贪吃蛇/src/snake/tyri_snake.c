/* Copyright (c) [2021] [tyri_ji]
 * [eating-snake] is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2. 
 * You may obtain a copy of Mulan PSL v2 at:
 *        http://license.coscl.org.cn/MulanPSL2 
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.  
 * See the Mulan PSL v2 for more details. * See the Mulan PSL v2 for more details.
 */

#include "tyri_snake.h"


void draw_food(Canvas canvas, Paint paint, int block_size)
{
	Canvas_drawRect(canvas, get_foodxy().x*block_size, get_foodxy().y*block_size, get_foodxy().x*block_size+block_size, get_foodxy().y*block_size+block_size, paint);
}

void draw_snake(Canvas canvas, Paint paint_head, Paint paint_body, Paint paint_tail, int block_size)
{
	snake_t *t1 = get_snake_head();
	while (t1 != null)
	{
		switch (t1->style)
		{
		case head_style:
			Canvas_drawRect(canvas, t1->x*block_size, t1->y*block_size, t1->x*block_size+block_size, t1->y*block_size+block_size, paint_head);
			break;
		case body_style:
			Canvas_drawRect(canvas, t1->x*block_size, t1->y*block_size, t1->x*block_size+block_size, t1->y*block_size+block_size, paint_body);
			break;
		case tail_style:
			Canvas_drawRect(canvas, t1->x*block_size, t1->y*block_size, t1->x*block_size+block_size, t1->y*block_size+block_size, paint_tail);
			break;
		default:
			// showToastText(" ERR: in func draw_snake(...). ", 1);
			break;
		}
		t1 = t1->next;
	}
}