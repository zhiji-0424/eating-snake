/* Copyright (c) [2021] [tyri_ji]
 * [eating-snake] is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2. 
 * You may obtain a copy of Mulan PSL v2 at:
 *        http://license.coscl.org.cn/MulanPSL2 
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.  
 * See the Mulan PSL v2 for more details. * See the Mulan PSL v2 for more details.
 */

#ifndef TYRI_SNAKE_H
#define TYRI_SNAKE_H


#include "snake.h"
#include "food.h"
#include "score.h"
#include "locals.h"
#include "../nativeView/base.h"


void draw_food(Canvas canvas, Paint paint, int block_size);
void draw_snake(Canvas canvas, Paint paint_head, Paint paint_body, Paint paint_tail, int block_size);


#endif